// Emula as APIs do Tampermonkey dentro do WebView
(function () {
  var P = 'cs_gm_';
  window.unsafeWindow = window;
  window.GM_getValue = function (k, d) {
    try { var v = localStorage.getItem(P + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; }
  };
  window.GM_setValue = function (k, v) { try { localStorage.setItem(P + k, JSON.stringify(v)); } catch (e) {} };
  window.GM_addStyle = function (css) {
    var s = document.createElement('style'); s.textContent = css;
    (document.head || document.documentElement).appendChild(s); return s;
  };
  window.GM_registerMenuCommand = function () { return 0; };
  window.GM_unregisterMenuCommand = function () {};
})();
