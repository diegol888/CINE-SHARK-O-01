Coloque aqui:
1) cine_sharkao.user.js  -> o seu userscript, SEM alterar nada (cole o conteudo inteiro)
2) hls.min.js (opcional)  -> baixe de https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js
